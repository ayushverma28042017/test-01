//package src.java.main;
//
//public final class  SealedExample2 implements SealedExample {
//    static void testSealedExample2(){
//        System.out.println("SealedExample2 Inise");
//    }
//}
