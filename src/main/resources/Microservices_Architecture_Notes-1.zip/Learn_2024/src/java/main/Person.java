package src.java.main;

public record Person (String name, String address) {
    public Person{
        if(name.length()<1){
            throw new RuntimeException("Cannot be an emty string");
        }
    }

    public static void main(String[] args) {
        Person p = new Person("abc","Blr");
        Person p1 = new Person("","Blr");
        System.out.printf("Person details :: "+p);
    }
}