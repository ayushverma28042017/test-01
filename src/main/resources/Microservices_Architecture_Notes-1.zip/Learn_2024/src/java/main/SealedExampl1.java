//package src.java.main;
//
//public final class SealedExampl1 implements SealedExample {
//    static void testSealedExample1(){
//        System.out.println("SealedExample1 Inise");
//    }
//}
//
