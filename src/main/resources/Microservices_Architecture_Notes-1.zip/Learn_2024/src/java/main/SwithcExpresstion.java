package src.java.main;

public class SwithcExpresstion {

    static String testSwithcExpression(String s){
        return  switch (s){
            case "A" ->   s+"A";
            default -> "Illegal";
        };
    }

    public static void main(String[] args) {
        System.out.println(testSwithcExpression("A"));
    }
}
