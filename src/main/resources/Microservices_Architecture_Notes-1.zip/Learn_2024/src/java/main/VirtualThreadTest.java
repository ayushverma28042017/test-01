//package src.java.main;
//
//import java.util.concurrent.Executor;
//import java.util.concurrent.ExecutorService;
//import java.util.concurrent.Executors;
//import java.util.concurrent.ThreadFactory;
//
//public class VirtualThreadTest {
//    public static void main(String[] args) {
//        ExecutorService executorService  = Executors.newVirtualThreadPerTaskExecutor();
//
//
//        Runnable printThread = () -> System.out.println(Thread.currentThread());
//        executorService.submit(printThread);
//
////        ThreadFactory virtualThreadFactory = Thread.ofVirtual().factory();
////        ThreadFactory kernelThreadFactory = Thread.ofPlatform().factory();
////
////        Thread virtualThread = virtualThreadFactory.newThread(printThread);
////        Thread kernelThread = kernelThreadFactory.newThread(printThread);
////        virtualThread.start();
////        kernelThread.start();
//
//    }
//}
