package src.java.main.string;

public class ReverseString2Pointer {
    public static void main(String[] args) {
        ReverseString2Pointer reverseString2Pointer = new ReverseString2Pointer();
        System.out.println(reverseString2Pointer.reverseString("Ayush"));
        System.out.println(reverseString2Pointer.pallindormString("abcdcba"));

    }

    String reverseString(String str){
        int start =0;
        int end = str.length()-1;
        char [] strC = str.toCharArray();
        while ((start<end)){
            char temp = strC[start];
            strC[start]= strC[end];
            strC[end]=temp;
            start++;
            end--;
        }
        return new String(strC);
    }

    boolean pallindormString(String str){
        int start =0;
        int end = str.length()-1;
        char [] strC = str.toCharArray();
        while ((start<end)) {
            if (strC[start] == strC[end]) {
                start++;
                end--;
            } else
                return false;
        }

        return true;
    }
}
