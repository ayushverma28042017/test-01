package src.java.main;

public record Employee(String nane, String dep,int salary,String address) {
}
