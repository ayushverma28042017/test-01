package src.java.main;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        Person person = new Person("ayush","Bangalore");


//        System.out.println(person);
        testStream();


//        SealedExample2.testSealedExample2();
//        SealedExampl1.testSealedExample1();
    }

    static void testStream(){
        List<Person> allPerson = new ArrayList<>();
        allPerson.add(new Person("Ayush","MUZ"));
        allPerson.add(new Person("Aayushi","BLR"));
        allPerson.add(new Person("Vihaa","BOM"));
        allPerson.add(new Person("Ishi","SIN"));

        // all person name who live in blor

        List<String> onlyNameLst =allPerson.stream()
                .filter(e-> e.address().equals("BLR"))
                .map(e-> e.name())
                .collect(Collectors.toList());


        List<String> uppercaseLst=allPerson.stream()
                        .map(e-> e.name().toUpperCase())
                                .collect(Collectors.toList());
//        uppercaseLst.forEach(System.out::println);

        List<List<Person>> listLstPerson = new ArrayList<>();
        listLstPerson.add(allPerson);

        List<String> listLstNmae =listLstPerson.stream().flatMap(e-> e.stream())
                .map(e-> e.name().toLowerCase())
                .collect(Collectors.toList());


        listLstNmae.forEach(System.out::println);



    }
}
