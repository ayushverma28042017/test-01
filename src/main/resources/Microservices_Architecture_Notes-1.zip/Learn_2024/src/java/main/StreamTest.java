package src.java.main;

import java.time.Duration;
import java.util.*;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

import static java.lang.Thread.sleep;

public class StreamTest {
    List<Employee> allEmployee = new ArrayList<>();
    public static void main(String[] args) throws Exception
    {
     StreamTest streamTest = new StreamTest();
//     streamTest.testStream();;
//     streamTest.testSteam2();;
//     streamTest.testStream3();

//        streamTest.concurrentMorningRoutineUsingExecutors();
        streamTest.reverseWithchangeNumberPosition();

    }
    public StreamTest(){
        Employee e1 = new Employee("Ayush","IT",5000,"Blr");
        Employee e2 = new Employee("RAvi","MGR",15000,"GGN");
        Employee e3 = new Employee("PR","HEAD",55000,"GGN");
        Employee e4 = new Employee("NN","DEV",25000,"GGN");
        Employee e5= new Employee("AA","HR",76000,"bom");
        allEmployee.add(e1);
        allEmployee.add(e2);
        allEmployee.add(e3);
        allEmployee.add(e4);
        allEmployee.add(e5);
    }

    void testStream(){
        List<String> names =allEmployee.stream()
                .filter(e-> e.salary()>15000)
                .map(e->e.nane())
                .collect(Collectors.toList());
        names.stream().forEach(System.out::println);
    }

    void testSteam2(){
         allEmployee.stream().map(e->e.nane().toUpperCase())
                .collect(Collectors.toList());
         allEmployee.stream().forEach(System.out::println);
    }

    void testStream3(){
        List<Employee> resultSorted =allEmployee.stream().sorted(Comparator.comparing(Employee::salary))
                .collect(Collectors.toList());
        resultSorted.stream().forEach(System.out::println);
    }

    void reverseWithchangeNumberPosition(){
//        String str ="abhdfs123bhd31";
        String str ="ab13kl";
        Stack<String> tempStack = new Stack<>();
        StringBuilder stringBuilder = new StringBuilder();
        Map<Integer,Character> digit = new HashMap<>();
        StringBuilder resut = new StringBuilder();
        for(int i=0;i<str.length();i++){
            if(Character.isDigit(str.toCharArray()[i])){
                digit.put(i,str.toCharArray()[i]);
            }
            else {
                stringBuilder.append(str.toCharArray()[i]);

            }
        }
        resut = stringBuilder.reverse();

        for (Map.Entry<Integer, Character> entry : digit.entrySet()) {
            resut.insert(entry.getKey(),entry.getValue().toString());
        }
        System.out.println("Original :: " + str);
     System.out.println("Solution  :: " +resut);



    }

//    static void concurrentMorningRoutineUsingExecutors() throws Exception{
//        try (var executor = Executors.newVirtualThreadPerTaskExecutor()) {
//            var bathTime =
//                    executor.submit(
//                            () -> {
//                                System.out.println("I'm going to take a bath");
//                                try {
//                                    sleep(Duration.ofMillis(500L));
//                                } catch (InterruptedException e) {
//                                    e.printStackTrace();
//                                }
//                                System.out.println("I'm done with the bath");
//                            });
//            var boilingWater =
//                    executor.submit(
//                            () -> {
//                                System.out.println("I'm going to boil some water");
//                                try {
//                                    sleep(Duration.ofSeconds(1L));
//                                } catch (InterruptedException e) {
//                                    e.printStackTrace();
//                                }
//                                System.out.println("I'm done with the water");
//                            });
//            bathTime.get();
//            boilingWater.get();
//        }
//    }
}


