package src.java.main.linklist;

public class MyLinkList {
   private Node head;

    void addNode(Node node){
        if( head== null){
            head=node;
            return;
        }
        Node temp =head;
        while (temp.next!=null){
            temp=temp.next;
        }
        temp.next=node;

    }
    void reverse(){
        Node current= head;
        Node prev=null;
        Node nextN = null;

        while (current.next!=null){
            nextN = current.next;
            current.next =prev;
            prev=current;
            current=nextN;

        }




    }

    void display(){
        Node temp=head;
        while (temp.next!=null){
            System.out.println(temp.data);
            temp=temp.next;
        }
    }

    public static void main(String[] args) {
        MyLinkList myLinkList = new MyLinkList();
        Node one = new Node(1,null);
        Node two = new Node(2,null);
        Node three = new Node(4,null);
        Node four = new Node(7,null);
        myLinkList.addNode(one);
        myLinkList.addNode(two);
        myLinkList.addNode(three);
        myLinkList.addNode(four);
        myLinkList.display();;
    }

}

class Node{
    public Node(int data, Node next) {
        this.data = data;
        this.next = next;
    }

    int data;
    Node next;
}