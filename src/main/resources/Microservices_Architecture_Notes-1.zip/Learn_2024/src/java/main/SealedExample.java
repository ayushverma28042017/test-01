//package src.java.main;
//
//public sealed interface SealedExample  permits  SealedExampl1{
//}
