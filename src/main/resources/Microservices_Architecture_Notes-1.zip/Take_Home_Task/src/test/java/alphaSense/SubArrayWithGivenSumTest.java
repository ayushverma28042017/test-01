package alphaSense;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class SubArrayWithGivenSumTest {
    SubArrayWithGivenSum subArrayWithGivenSum = new SubArrayWithGivenSum();

    @Test
    @DisplayName("Simple SubArrayWithGivenSum should work")
    public void testSubArrayWithGivenSum_01() {
        int[] arr = {1, 2,3,4};
        int targetSum = 7;
        assertEquals(true, subArrayWithGivenSum.findSubarrayWithGivenSum(arr,targetSum),
                "Regular SubArrayWithGivenSum should work");
    }
    @Test
    @DisplayName("Simple SubArrayWithGivenSum should work")
    public void testSubArrayWithGivenSum_02() {
        int[] arr = {1, 2,3,4,8};
        int targetSum = 100;
        assertEquals(false, subArrayWithGivenSum.findSubarrayWithGivenSum(arr,targetSum),
                "Regular SubArrayWithGivenSum should work");
    }
    @Test
    @DisplayName("Simple SubArrayWithGivenSum should work")
    public void testSubArrayWithGivenSum_03() {
        int[] arr = {1};
        int targetSum = 1;
        assertEquals(true, subArrayWithGivenSum.findSubarrayWithGivenSum(arr,targetSum),
                "Regular SubArrayWithGivenSum should work");
    }
    @Test
    @DisplayName("Simple SubArrayWithGivenSum should work")
    public void testSubArrayWithGivenSum_04() {
        int[] arr = null;
        int targetSum = 9;
        Throwable exception = assertThrows(RuntimeException.class, () -> subArrayWithGivenSum.findSubarrayWithGivenSum(arr,targetSum));
        assertEquals("Input array cannot be null.", exception.getMessage());
    }


}
