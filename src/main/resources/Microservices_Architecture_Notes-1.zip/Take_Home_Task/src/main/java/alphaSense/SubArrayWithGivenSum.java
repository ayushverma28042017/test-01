package alphaSense;


import java.util.HashMap;
import java.util.Map;

/**
 *
 */
public class SubArrayWithGivenSum {


    /**
     * function which returns true
     * if there is a continuous subarray which adds to a given number(target here)
     * @param arr input array
     * @param target target sum
     * @return true if find
     * Time Complexity: O(N)
     * Auxiliary Space: O(N)
     */
    public  boolean findSubarrayWithGivenSum(int[] arr, int target) {
        if(null== arr){
            throw new RuntimeException("Input array cannot be null.");
        }
        Map<Integer, Integer> map = new HashMap<>();
        int currSum = 0;
        for (int i = 0; i < arr.length; i++) {
            currSum += arr[i];
            if (currSum == target) {
                return true;
            }
            if (map.containsKey(currSum - target)) {
                return true;
            }
            map.put(currSum, i);
        }
        return false;
    }




}
