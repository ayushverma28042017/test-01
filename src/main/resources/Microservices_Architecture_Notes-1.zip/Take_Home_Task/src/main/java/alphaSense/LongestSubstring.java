package alphaSense;

import java.util.HashMap;
import java.util.Map;

/**
 * @Class to find length of Longest substring without repeating characters
 */
public class LongestSubstring {


    /**
     * Method to find th lenght Longest substring without repeating characters
     * @param str input string
     * @return length of Longest substring
     */
    public int longestSubString(String str) {
        if(null == str){
            throw new RuntimeException("Input String cannot be null.");
        }
        int maxLength = 0;
        Map<Character, Integer> map = new HashMap<>();

        for (int left = 0, right = 0; right < str.length(); right++) {
            char currentChar = str.charAt(right);

            if (map.containsKey(currentChar)) {
                left = Math.max(left, map.get(currentChar) + 1);
            }

            map.put(currentChar, right);
            maxLength = Math.max(maxLength, right - left + 1);
        }

        return maxLength;
    }


}

